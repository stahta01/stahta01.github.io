/////////////////////////////////////////////////////////////////////////////
// Name:        src/gtk/gnome/gprint.cpp
// Author:      Robert Roebling
// Purpose:     Implement GNOME printing support
// Created:     09/20/04
// RCS-ID:      $Id: gprint.cpp 37063 2006-01-23 01:14:32Z MR $
// Copyright:   Robert Roebling
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif
