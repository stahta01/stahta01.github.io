This is a templated that was tested using files from two locations.
MinGW-w64_v4.8.1-tdm64-01.exe from wxPack site.
WARNING: MinGW-w64_v4.8.1-tdm64-01.exe set the Windows Enviromental Variable GCC_ROOT which needs deleted before other MinGW GCC can work correctly.
wxWidgets-3.0.2_headers.7z and wxMSW-3.0.2_gcc481TDM_x64_Dev.7z from wxWidgets site.

CB Project uses 
	CB Compiler name: mingw-w64_481
	CB Global Variable: wxbase30

CB Global Variable setup
	base: 		C:\SourceCode\OpenSourceCode\Libs\GUI\wxWidgets
	include: 	C:\SourceCode\OpenSourceCode\Libs\GUI\wxWidgets\wxWidgets-3.0.2_headers\include
	lib: 			C:\SourceCode\OpenSourceCode\Libs\GUI\wxWidgets\wxMSW-3.0.2_gcc481TDM_x64_Dev\lib
 