/***************************************************************
 * Name:      wx30App.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2015-01-12
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef WX30APP_H
#define WX30APP_H

#include <wx/app.h>

class wx30App : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // WX30APP_H
