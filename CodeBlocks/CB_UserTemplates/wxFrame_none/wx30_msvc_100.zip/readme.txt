This is a templated that was tested using files from the wxWidgets site.
wxWidgets-3.0.2_headers.7z, wxMSW-3.0.2_vc100_ReleaseDLL.7z and wxMSW-3.0.2_gcc471TDM_Dev.7z

CB Project uses 
	CB Compiler name: Microsoft Visual C++ 2010 (msvc10)
	CB Global Variable: wxbase30

CB Global Variable setup
	base: 		C:\SourceCode\OpenSourceCode\Libs\GUI\wxWidgets
	include: 	C:\SourceCode\OpenSourceCode\Libs\GUI\wxWidgets\wxWidgets-3.0.2_headers\include
	lib: 			C:\SourceCode\OpenSourceCode\Libs\GUI\wxWidgets\wxMSW-3.0.2_gcc471TDM_Dev\lib
	bin:      C:\SourceCode\OpenSourceCode\Libs\GUI\wxWidgets\wxMSW-3.0.2_vc100_ReleaseDLL\lib\vc100_dll
	

